# segfaultLibft

This compare your libft behavior against the standard library.
This test doesnt quite work. (but the green stuff can make you feel a bit better about yourself)

## Usage

- `> make f` run test
- `> make pretty` run test with pretty output
