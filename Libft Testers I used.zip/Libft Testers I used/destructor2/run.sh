#!/bin/sh
python3 run.py $1 $2
